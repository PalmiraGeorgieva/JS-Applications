async function lockedProfile() {
    const url = `http://localhost:3030/jsonstore/advanced/profiles`;
    const main = document.getElementById('main');
    main.innerHTML = '';

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Failed to fetch profiles');
        }

        const data = await response.json();
        Object.values(data).forEach((profile, i) => {
            main.appendChild(createProfile(profile, i + 1));
        });
    } catch (err) {
        console.error('Error:', err.message);
    }
}

function createProfile(profile, index) {
    const div = document.createElement('div');
    div.classList.add('profile');

    const img = document.createElement('img');
    img.src = './iconProfile2.png';
    img.classList.add('userIcon');

    const labelLock = document.createElement('label');
    labelLock.textContent = 'Lock';

    const inputLock = document.createElement('input');
    inputLock.type = 'radio';
    inputLock.name = `user${index}Locked`;
    inputLock.value = 'lock';
    inputLock.checked = true;

    const labelUnlock = document.createElement('label');
    labelUnlock.textContent = 'Unlock';

    const inputUnlock = document.createElement('input');
    inputUnlock.type = 'radio';
    inputUnlock.name = `user${index}Locked`;
    inputUnlock.value = 'unlock';

    const br = document.createElement('br');
    const hr = document.createElement('hr');

    const labelUsername = document.createElement('label');
    labelUsername.textContent = 'Username';

    const inputUsername = document.createElement('input');
    inputUsername.type = 'text';
    inputUsername.name = `user${index}Username`;
    inputUsername.value = profile.username;
    inputUsername.disabled = true;
    inputUsername.readOnly = true;

    
    const hiddenDiv = document.createElement('div');
    hiddenDiv.classList.add(`user${index}Username`);
    hiddenDiv.id = `user${index}HiddenFields`;
    hiddenDiv.style.display = 'none';

    const hr2 = document.createElement('hr');

    const labelEmail = document.createElement('label');
    labelEmail.textContent = 'Email:';

    const inputEmail = document.createElement('input');
    inputEmail.type = 'email';
    inputEmail.name = `user${index}Email`;
    inputEmail.value = profile.email;
    inputEmail.disabled = true;
    inputEmail.readOnly = true;

    const labelAge = document.createElement('label');
    labelAge.textContent = 'Age:';

    const inputAge = document.createElement('input');
    inputAge.type = 'number';
    inputAge.name = `user${index}Age`;
    inputAge.value = profile.age;
    inputAge.disabled = true;
    inputAge.readOnly = true;

    hiddenDiv.appendChild(hr2);
    hiddenDiv.appendChild(labelEmail);
    hiddenDiv.appendChild(inputEmail);
    hiddenDiv.appendChild(labelAge);
    hiddenDiv.appendChild(inputAge);

    const btn = document.createElement('button');
    btn.textContent = 'Show more';

    btn.addEventListener('click', () => {
        if (!inputLock.checked) {
            if (hiddenDiv.style.display === 'none') {
                hiddenDiv.style.display = 'block';
                btn.textContent = 'Hide it';
            } else {
                hiddenDiv.style.display = 'none';
                btn.textContent = 'Show more';
            }
        }
    });

    div.appendChild(img);
    div.appendChild(labelLock);
    div.appendChild(inputLock);
    div.appendChild(labelUnlock);
    div.appendChild(inputUnlock);
    div.appendChild(br);
    div.appendChild(hr);
    div.appendChild(labelUsername);
    div.appendChild(inputUsername);
    div.appendChild(hiddenDiv);
    div.appendChild(btn);

    return div;
}

lockedProfile();

