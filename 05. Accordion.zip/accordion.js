async function solution() {
    const BASE_URL = 'http://localhost:3030/jsonstore/advanced/articles/list'
    const mainSectionRef = document.getElementById('main')

    const response = await fetch(BASE_URL)
    const data = await response.json()

    data.forEach(article => {
        const accordionDiv = document.createElement('div')
        accordionDiv.classList.add('accordion');

        const headDiv = document.createElement('div')
        headDiv.classList.add('head');

        const spanTitle = document.createElement('span')
        spanTitle.textContent = article.title

        const btn = document.createElement('button')
        btn.classList.add('button')
        btn.id = article._id
        btn.textContent = 'More'
        btn.addEventListener('click', toggle)

        headDiv.appendChild(spanTitle)
        headDiv.appendChild(btn)

        const divExtra = document.createElement('div')
        divExtra.classList.add('extra')
        divExtra.style.display = 'none'

        accordionDiv.appendChild(headDiv)
        accordionDiv.appendChild(divExtra)
        mainSectionRef.appendChild(accordionDiv)


    });

    async function toggle(e) {
        const btn = e.target
        const extra = btn.parentElement.nextElementSibling

        const URL = 'http://localhost:3030/jsonstore/advanced/articles/details/'

        if (btn.textContent === 'More') {
            const id = btn.id

            const res = await fetch(URL + id)
            const data = await res.json()

            const p = document.createElement('p')
            p.textContent = data.content
            btn.textContent = 'Less'
            extra.appendChild(p)
            extra.style.display = 'block'
        } else {
            extra.style.display = 'none'
            p.textContent = 'More'
        }

    }
}
solution()


