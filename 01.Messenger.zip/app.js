function attachEvents() {
     const BASE_URL = 'http://localhost:3030/jsonstore/messenger';
    const messagesArea = document.getElementById('messages');
    const authorInput = document.querySelector('input[name="author"]');
    const contentInput = document.querySelector('input[name="content"]');
    const sendBtn = document.getElementById('submit');
    const refreshBtn = document.getElementById('refresh');

    sendBtn.addEventListener('click', sendMessage);
    refreshBtn.addEventListener('click', loadMessages);

    async function sendMessage() {
        const author = authorInput.value.trim();
        const content = contentInput.value.trim();

        if (!author || !content) {
            return;
        }

        const message = { author, content };

        try {
            await fetch(BASE_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(message)
            });
            authorInput.value = '';
            contentInput.value = '';
        } catch (err) {
            console.error('Error sending message:', err);
        }
    }

    async function loadMessages() {
        try {
            const res = await fetch(BASE_URL);
            const data = await res.json();

            messagesArea.value = Object
                .values(data)
                .map(m => `${m.author}: ${m.content}`)
                .join('\n');

        } catch (err) {
            console.error('Error loading messages:', err);
        }
    }

    
}

attachEvents();