const baseUrl = 'http://localhost:3030/jsonstore/collections/students';
const form = document.getElementById('form');
const tbody = document.querySelector('#results tbody');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(form);
    const firstName = formData.get('firstName').trim();
    const lastName = formData.get('lastName').trim();
    const facultyNumber = formData.get('facultyNumber').trim();
    const grade = formData.get('grade').trim();

    if (!firstName || !lastName || !facultyNumber || !grade) {
        return; 
    }

    const student = {
        firstName,
        lastName,
        facultyNumber,
        grade
    };

    await fetch(baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(student)
    });

    form.reset();
    loadStudents();
});

async function loadStudents() {
    tbody.innerHTML = '';
    const res = await fetch(baseUrl);
    const data = await res.json();

    Object.values(data).forEach(student => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${student.firstName}</td>
            <td>${student.lastName}</td>
            <td>${student.facultyNumber}</td>
            <td>${student.grade}</td>
        `;
        tbody.appendChild(tr);
    });
}


window.addEventListener('load', loadStudents);
