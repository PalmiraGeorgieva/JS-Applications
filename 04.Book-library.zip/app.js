const baseUrl = 'http://localhost:3030/jsonstore/collections/books';
const tbody = document.querySelector('table tbody');
const form = document.querySelector('form');
const titleInput = form.querySelector('input[name="title"]');
const authorInput = form.querySelector('input[name="author"]');
const loadBtn = document.getElementById('loadBooks');

loadBtn.addEventListener('click', loadBooks);
form.addEventListener('submit', onSubmit);

// Зареждане при стартиране
loadBooks();

async function loadBooks() {
    tbody.innerHTML = '';
    const res = await fetch(baseUrl);
    const data = await res.json();

    Object.entries(data).forEach(([id, book]) => {
        const tr = document.createElement('tr');
        tr.dataset.id = id;

        tr.innerHTML = `
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>
                <button class="edit">Edit</button>
                <button class="delete">Delete</button>
            </td>
        `;

        tr.querySelector('.delete').addEventListener('click', () => deleteBook(id));
        tr.querySelector('.edit').addEventListener('click', () => editBook(id, book));

        tbody.appendChild(tr);
    });
}

async function onSubmit(e) {
    e.preventDefault();

    const title = titleInput.value.trim();
    const author = authorInput.value.trim();
    if (!title || !author) return;

    await fetch(baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, author })
    });

    form.reset();
    loadBooks();
}

async function deleteBook(id) {
    await fetch(`${baseUrl}/${id}`, { method: 'DELETE' });
    loadBooks();
}

function editBook(id, book) {
    titleInput.value = book.title;
    authorInput.value = book.author;

    form.removeEventListener('submit', onSubmit);
    form.addEventListener('submit', onSave);

    async function onSave(e) {
        e.preventDefault();

        const title = titleInput.value.trim();
        const author = authorInput.value.trim();
        if (!title || !author) return;

        await fetch(`${baseUrl}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, author })
        });

        form.reset();
        form.removeEventListener('submit', onSave);
        form.addEventListener('submit', onSubmit);
        loadBooks();
    }
}





