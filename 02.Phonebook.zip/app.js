function attachEvents() {
    const BASE_URL = 'http://localhost:3030/jsonstore/phonebook';
    const phonebookRef = document.getElementById('phonebook');
    const personRef = document.getElementById('person');
    const phoneRef = document.getElementById('phone');

    document.getElementById('btnLoad').addEventListener("click", onLoad);
    document.getElementById('btnCreate').addEventListener("click", onCreate);

    async function onLoad() {
        const response = await fetch(BASE_URL);
        const data = await response.json();

        phonebookRef.innerHTML = '';

        Object.values(data).forEach(createRec);
    }

    async function onCreate() {
        const person = personRef.value.trim();
        const phone = phoneRef.value.trim();

        if (!person || !phone) {
            return;
        }

        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ person, phone })
        };

        await fetch(BASE_URL, options);

        personRef.value = '';
        phoneRef.value = '';

        await onLoad();
    }

    function createRec(data) {
        const li = document.createElement('li');
        li.textContent = `${data.person}: ${data.phone}`;

        const btn = document.createElement('button');
        btn.textContent = 'Delete';
        btn.addEventListener('click', () => onDelete(data._id));

        li.appendChild(btn);
        phonebookRef.appendChild(li);
    }

    async function onDelete(id) {
        await fetch(`${BASE_URL}/${id}`, { method: 'DELETE' });
        await onLoad();
    }
}

attachEvents();