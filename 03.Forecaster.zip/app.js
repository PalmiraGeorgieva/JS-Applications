function attachEvents() {
    document.getElementById('submit').addEventListener('click', onSubmit);
    const locationRef = document.getElementById('location');
    const forcastRef = document.getElementById('forecast');
    const current = document.getElementById('current');
    const upcoming = document.getElementById('upcoming')

    const BASE_URL = 'http://localhost:3030/jsonstore/forecaster/';
    const endPoint = {
        location: () => `locations`,
        today: (str) => `today/${str}`,
        upcoming: (str) => `upcoming/${str}`
    }

    const symbolEnum = {
      'Sunny': '&#x2600',
      'Partly sunny': '&#x26C5', // ⛅
      'Overcast': '&#x2601', // ☁
      'Rain': '&#x2614', // ☂
      'Degrees': '&#176' // °

    }

    async function onSubmit(e) {
        try {
            const response = await fetch(BASE_URL + endPoint.location());
            const data = await response.json();
            const userLocation = locationRef.value

            forcastRef.style.display = 'block';
            current.innerHTML = '<div class="label">Current conditions</div>';
            upcoming.innerHTML = '<div class="label">Three-day forecast</div>';

            const userPref = data.find(x => x.name === userLocation);
            if (!userPref) {
                throw new Error('Invalid location');
            }
            fillToday(userPref.code);
            fillNextDay(userPref.code)
            
        } catch (error) {
            forcastRef.textContent = 'Error';
            
        }
       

    }
    async function fillToday(code) {
        try {
            const response = await fetch(BASE_URL + endPoint.today(code));
            const data = await response.json();

            createTodayInfo(data)

            
        } catch (error) {
            forcastRef.textContent = 'Error'
            
        }
        
    }

    async function fillNextDay(code) {
        const response = await fetch(BASE_URL + endPoint.upcoming(code));
        const data = await response.json();

        createNextDay(data)
        
    }

    function createNextDay(data){
        const container = document.createElement('div')
        container.classList.add('forecast-info');
        data.forecast.forEach(x => {
            const forecastData = x
            const spanContainer = generateSpan(['upcoming'], '');
            const spSymbol = generateSpan(['symbol'], symbolEnum[forecastData.condition])
            const spDeg = generateSpan(['forecast-data'], `${forecastData.low}${symbolEnum.Degrees}/${forecastData.high}${symbolEnum.Degrees}`)
            const spCondition = generateSpan(['forecast-data'], forecastData.condition);

            spanContainer.appendChild(spSymbol)
            spanContainer.appendChild(spDeg)
            spanContainer.appendChild(spCondition)
            container.appendChild(spanContainer)
        })
        upcoming.appendChild(container)

    }

    function createTodayInfo(data){
        const forecastData = data.forecast
        const container = document.createElement('div');
        container.classList.add('forecasts');
        const sp1 = generateSpan(['condition', 'symbol'], symbolEnum[data.forecast.condition]);
        const spanContainer = generateSpan(['condition'])
        const spName = generateSpan(['forecast-data'], data.name);
        const spDeg = generateSpan(['forecast-data'], `${forecastData.low}${symbolEnum.Degrees}/${forecastData.high}${symbolEnum.Degrees}`)
        const spCondition = generateSpan(["forecast-data"], forecastData.condition);

        spanContainer.appendChild(spName);
        spanContainer.appendChild(spDeg);
        spanContainer.appendChild(spCondition);

        container.appendChild(sp1);
        container.appendChild(spanContainer);

        current.appendChild(container)
    }

    function generateSpan(classList, value){
        const span = document.createElement('span');
        classList.forEach(x => span.classList.add(x));
        span.innerHTML = value


        return span

    }

}

attachEvents();